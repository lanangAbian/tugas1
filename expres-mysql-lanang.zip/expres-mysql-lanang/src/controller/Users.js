const getAllUser =  (req, res) => {
    const data = {
        id: '001',
        name : "Lanang Abian G",
        email : "giverrolanangabian@gmail.com",
        address : "Malang"
    }
    res.json({
        massage: 'GET All Users succes',
        data : data
    })
};

const CreateNewUser =  (req, res) => {
    console.log(req.body);
    res.json({
        massage: 'Create New user succes',
        data: req.body
    })
};

const updateUser = (req, res) =>{
    const {id} = req.params;
    console.log('IdUser: ' ,id);
    res.json({
        message: 'UPDATE User Success',
        data: req.body,
    })
}

module.exports = {
    getAllUser,
    CreateNewUser,
    updateUser,
};
